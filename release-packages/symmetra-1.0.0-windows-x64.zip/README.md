# Symmetra v1.0.0
GPU-accelerated TypeScript compiler.

## Quick Start
Run install.ps1 or place sym.exe anywhere in your PATH.

sym --version
